declare module 'react-bootstrap-table2-paginator';
declare module 'react-bootstrap-table2-toolkit';
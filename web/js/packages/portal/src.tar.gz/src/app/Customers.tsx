import React, { useEffect } from 'react';
import { Navigate } from "react-router-dom";


function Dashboard() {


    return (
        <div>
         Customers
        </div>
    )
}

export default Dashboard;
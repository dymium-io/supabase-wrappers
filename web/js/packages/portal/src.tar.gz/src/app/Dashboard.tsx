import React, { useEffect } from 'react';
import { Navigate } from "react-router-dom";
import './Dashboard.scss';

function Dashboard() {
    return (
        <div className="pl-4 pt-4">
   

         <div className="dashboard">
 


         </div>
        </div>
    )
}

export default Dashboard;